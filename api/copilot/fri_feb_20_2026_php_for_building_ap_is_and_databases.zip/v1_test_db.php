<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

use App\Config\Database;

try {
    echo "Attempting to connect to database...\n";
    $db = Database::getInstance();
    echo "✓ Database connection successful\n";
    
    echo "Database path: " . DB_PATH . "\n";
    
    echo "Initializing tables...\n";
    $db->initializeTables();
    echo "✓ Tables initialized\n";
    
    // Test query
    echo "Testing query...\n";
    $conn = $db->getConnection();
    $stmt = $conn->query('SELECT COUNT(*) as count FROM movies');
    $result = $stmt->fetch();
    echo "✓ Query successful. Movies count: " . $result['count'] . "\n";
    
} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "Trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}

echo "\n✓ All checks passed!\n";