<?php
// Database configuration
// Use absolute path or relative path from project root
$projectRoot = __DIR__;
define('DB_PATH', $projectRoot . '/movies.db');

// JWT configuration
define('JWT_SECRET', getenv('JWT_SECRET') ?? 'your-secret-key-change-in-production');
define('JWT_ALGORITHM', 'HS256');
define('JWT_EXPIRATION', 3600); // 1 hour

// API configuration
define('API_VERSION', '1.0.0');
define('ENVIRONMENT', getenv('ENVIRONMENT') ?? 'development');

// CORS allowed origins
define('ALLOWED_ORIGINS', [
    'http://localhost:3000',
    'http://localhost:8000',
    'https://yourdomain.com'
]);

return [
    'db_path' => DB_PATH,
    'jwt_secret' => JWT_SECRET,
    'jwt_algorithm' => JWT_ALGORITHM,
    'jwt_expiration' => JWT_EXPIRATION,
];