<?php
namespace App\Config;

use PDO;
use PDOException;

class Database
{
    private static $instance = null;
    private $connection;

    private function __construct()
    {
        try {
            // Get the directory where the database should be stored
            $dbDir = dirname(DB_PATH);
            
            // Create directory if it doesn't exist
            if (!is_dir($dbDir)) {
                if (!mkdir($dbDir, 0755, true)) {
                    throw new \Exception("Could not create database directory: $dbDir");
                }
                error_log("Created database directory: $dbDir");
            }
            
            // Check if directory is writable
            if (!is_writable($dbDir)) {
                throw new \Exception("Database directory is not writable: $dbDir");
            }
            
            error_log("Connecting to database: " . DB_PATH);
            
            // Connect to SQLite database - this creates the file if it doesn't exist
            $this->connection = new PDO(
                'sqlite:' . DB_PATH,
                null,
                null,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
            
            // Enable foreign keys
            $this->connection->exec('PRAGMA foreign_keys = ON');
            
            error_log('✓ Database connected: ' . DB_PATH);
            error_log('Database file exists: ' . (file_exists(DB_PATH) ? 'yes' : 'no'));
            
        } catch (PDOException $e) {
            error_log('✗ PDO Exception: ' . $e->getMessage());
            throw new \Exception('Database connection failed: ' . $e->getMessage());
        } catch (\Exception $e) {
            error_log('✗ Exception: ' . $e->getMessage());
            throw $e;
        }
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection()
    {
        return $this->connection;
    }

    public function initializeTables()
    {
        try {
            // Check if tables already exist
            $tables = $this->connection->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll();
            $existingTables = array_column($tables, 'name');
            
            if (in_array('movies', $existingTables)) {
                error_log('✓ Tables already exist');
                return;
            }
            
            error_log('Creating tables...');

            $this->connection->exec('
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT DEFAULT "user",
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ');
            error_log('✓ Users table created');

            $this->connection->exec('
                CREATE TABLE IF NOT EXISTS movies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    year INTEGER,
                    director TEXT,
                    rating REAL DEFAULT 0,
                    created_by INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (created_by) REFERENCES users(id)
                )
            ');
            error_log('✓ Movies table created');

            $this->connection->exec('
                CREATE TABLE IF NOT EXISTS reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    movie_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    rating REAL NOT NULL,
                    comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (movie_id) REFERENCES movies(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ');
            error_log('✓ Reviews table created');
            
            error_log('✓ All tables created successfully');
            
        } catch (PDOException $e) {
            error_log('✗ PDOException in table creation: ' . $e->getMessage());
            throw new \Exception('Table creation failed: ' . $e->getMessage());
        } catch (\Exception $e) {
            error_log('✗ Exception in table creation: ' . $e->getMessage());
            throw $e;
        }
    }
}