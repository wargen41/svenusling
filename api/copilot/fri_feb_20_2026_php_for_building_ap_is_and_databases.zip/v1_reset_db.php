<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

use App\Config\Database;

try {
    echo "Resetting database...\n";
    
    // Delete database file if it exists
    if (file_exists(DB_PATH)) {
        unlink(DB_PATH);
        echo "✓ Deleted old database\n";
    }
    
    // Create new database with fresh schema
    $db = Database::getInstance();
    $db->initializeTables();
    
    echo "✓ Database reset successfully!\n";
    echo "Database path: " . DB_PATH . "\n";
    
} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}