<?php
// Enable error reporting for development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../config.php';

use Slim\Factory\AppFactory;
use App\Config\Database;
use App\Routes;

try {
    // Initialize database
    $db = Database::getInstance();
    $db->initializeTables();
} catch (\Exception $e) {
    // Return error response if database fails
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode([
        'error' => 'Database initialization failed',
        'message' => $e->getMessage(),
        'trace' => ENVIRONMENT === 'development' ? $e->getTraceAsString() : null
    ]);
    exit;
}

// Create Slim app
$app = AppFactory::create();

// Add error handling middleware with detailed errors in development
$errorMiddleware = $app->addErrorMiddleware(
    ENVIRONMENT === 'development', // displayErrorDetails
    true,  // logErrors
    true   // logErrorDetails
);

// Add custom error handler
$errorMiddleware->setDefaultErrorHandler(function ($request, $exception, $displayErrorDetails) {
    $payload = [
        'error' => $exception->getMessage(),
    ];
    
    if ($displayErrorDetails) {
        $payload['file'] = $exception->getFile();
        $payload['line'] = $exception->getLine();
        $payload['trace'] = $exception->getTraceAsString();
    }
    
    $response = new \Slim\Psr7\Response();
    $response->getBody()->write(json_encode($payload));
    
    return $response
        ->withStatus($exception->getCode() ?: 500)
        ->withHeader('Content-Type', 'application/json');
});

// Add CORS middleware
$app->add(function ($request, $handler) {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        ->withHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
});

// Handle preflight requests
$app->options('/{routes:.+}', function ($request, $response) {
    return $response;
});

// Register routes
try {
    Routes::register($app);
} catch (\Exception $e) {
    error_log('Route registration failed: ' . $e->getMessage());
    throw $e;
}

// Run app
$app->run();