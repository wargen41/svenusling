<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

use App\Config\Database;

$username = $argv[1] ?? 'testuser';

try {
    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare('UPDATE users SET role = ? WHERE username = ?');
    $stmt->execute(['admin', $username]);
    
    if ($stmt->rowCount() > 0) {
        echo "✓ User '$username' is now admin\n";
    } else {
        echo "✗ User '$username' not found\n";
    }
    
} catch (\Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    exit(1);
}